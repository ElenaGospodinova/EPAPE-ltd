
const hamburger_menu = document.querySelector(".hamburger-menu");
const container = document.querySelector(".container");

hamburger_menu.addEventListener("click", () => {
  container.classList.toggle("active");
});



/* navbar About page START*/







/* navbar About page END*/





/* START content info on Services page */
/* START content info on Services page */





/* END of content info on SERVICES page */
/* END of content info on SERVICES page */



/* logo animation*/






/* logo animation*/